# FraudGuard AI — Financial Risk & Rule-Based Fraud Detection

A beginner-friendly Flask web app for demonstrating transaction monitoring, risk scoring, fraud alerts, and a dashboard. It uses SQLite by default so it runs immediately without configuring MySQL.

## Run on Windows (PyCharm terminal / PowerShell)

1. Open this project folder in PyCharm.
2. Create and activate a virtual environment:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
3. Install requirements:
   ```powershell
   python -m pip install -r requirements.txt
   ```
4. Start the site:
   ```powershell
   python app.py
   ```
5. Open **http://127.0.0.1:5000/login**

## Demo login
- Username: `admin`
- Password: `Demo@123`

## Pages
- `/` — Dashboard
- `/transactions` — searchable transaction table and status filter
- `/risk-analysis` — risk scores sorted highest first
- `/alerts` — flagged and review alerts
- `/add-transaction` — enter a transaction and apply the demo rule: score >= 70 = FLAGGED, 40–69 = UNDER REVIEW, below 40 = APPROVED
- `/api/health` — basic health endpoint

## Important
This is a demo/student project, not a production banking security system. It uses a fixed demo login and SQLite. Before public deployment, replace the demo authentication with secure password hashing, set a strong secret key via environment variables, use HTTPS, validate inputs further, and configure a production database. Do not upload real customer or financial data.

## Public deployment (optional)

On Render, connect the GitHub repository as a **Web Service**. Use build command `pip install -r requirements.txt` and start command `gunicorn app:app`. Render will provide the public URL after deployment completes. A public URL cannot be created until you sign in and authorize a hosting account and connect the repository. See the [official Render Flask guide](https://render.com/docs/deploy-flask).
