from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from pathlib import Path
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = "change-this-secret-before-deployment"
DB_PATH = Path(__file__).with_name("fraudguard.db")

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_id TEXT UNIQUE NOT NULL,
            customer TEXT NOT NULL,
            amount REAL NOT NULL,
            location TEXT NOT NULL,
            transaction_time TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            status TEXT NOT NULL,
            fraud_type TEXT NOT NULL
        )""")
        count = con.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        if count == 0:
            rows = [
                ("TXN-2024-007","Luxury Electronics Store",15750,"Miami, FL","Jan 15, 15:32",87,"FLAGGED","Card Not Present"),
                ("TXN-2024-006","Casino Royal",500,"Las Vegas, NV","Jan 15, 04:45",92,"FLAGGED","Unusual Spending"),
                ("TXN-2024-005","Global Coffee Chain",89.99,"New York, NY","Jan 15, 09:15",23,"APPROVED","Normal Activity"),
                ("TXN-2024-004","Crypto Exchange Pro",2500,"San Francisco, CA","Jan 15, 12:20",78,"UNDER REVIEW","Account Takeover"),
                ("TXN-2024-003","Downtown Gas Station",45.67,"Chicago, IL","Jan 15, 17:45",15,"APPROVED","Normal Activity"),
                ("TXN-2024-002","Online Gadget Hub",4200,"São Paulo, Brazil","Jan 15, 11:02",81,"FLAGGED","Location Anomaly"),
                ("TXN-2024-001","Travel World",1890,"London, UK","Jan 15, 10:22",67,"UNDER REVIEW","Velocity Check"),
                ("TXN-2023-998","Fresh Market",62.40,"Austin, TX","Jan 14, 18:10",12,"APPROVED","Normal Activity"),
            ]
            con.executemany("""INSERT INTO transactions
                (transaction_id,customer,amount,location,transaction_time,risk_score,status,fraud_type)
                VALUES (?,?,?,?,?,?,?,?)""", rows)

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapped

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        # Demo-only credentials; replace with hashed users for real deployment.
        if username == "admin" and password == "Demo@123":
            session["logged_in"] = True
            session["username"] = username
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Incorrect username or password. Use the demo credentials shown below.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    with connect() as con:
        all_rows = con.execute("SELECT * FROM transactions ORDER BY id DESC").fetchall()
    total = len(all_rows)
    flagged = sum(r["status"] == "FLAGGED" for r in all_rows)
    high_risk = sum(r["risk_score"] >= 70 for r in all_rows)
    review = sum(r["status"] == "UNDER REVIEW" for r in all_rows)
    return render_template("dashboard.html", transactions=all_rows, total=total,
                           flagged=flagged, high_risk=high_risk, review=review, active="dashboard")

@app.route("/transactions")
@login_required
def transactions():
    search = request.args.get("q", "").strip()
    status = request.args.get("status", "ALL")
    with connect() as con:
        sql = "SELECT * FROM transactions WHERE (transaction_id LIKE ? OR customer LIKE ? OR location LIKE ?)"
        like = f"%{search}%"
        args = [like, like, like]
        if status != "ALL":
            sql += " AND status = ?"
            args.append(status)
        sql += " ORDER BY id DESC"
        rows = con.execute(sql, args).fetchall()
    return render_template("transactions.html", transactions=rows, q=search, status=status, active="transactions")

@app.route("/risk-analysis")
@login_required
def risk_analysis():
    with connect() as con:
        rows = con.execute("SELECT * FROM transactions ORDER BY risk_score DESC").fetchall()
    return render_template("risk_analysis.html", transactions=rows, active="risk")

@app.route("/alerts")
@login_required
def alerts():
    with connect() as con:
        rows = con.execute("SELECT * FROM transactions WHERE status != 'APPROVED' ORDER BY risk_score DESC").fetchall()
    return render_template("alerts.html", transactions=rows, active="alerts")

@app.route("/add-transaction", methods=["GET", "POST"])
@login_required
def add_transaction():
    if request.method == "POST":
        try:
            tid = request.form["transaction_id"].strip()
            customer = request.form["customer"].strip()
            amount = float(request.form["amount"])
            location = request.form["location"].strip()
            risk = int(request.form["risk_score"])
            if not tid or not customer or not location or amount < 0 or not 0 <= risk <= 100:
                raise ValueError()
            status = "FLAGGED" if risk >= 70 else ("UNDER REVIEW" if risk >= 40 else "APPROVED")
            fraud_type = "Rule-based risk alert" if risk >= 40 else "Normal Activity"
            with connect() as con:
                con.execute("""INSERT INTO transactions
                (transaction_id,customer,amount,location,transaction_time,risk_score,status,fraud_type)
                VALUES (?,?,?,?,?,?,?,?)""",
                (tid, customer, amount, location, datetime.now().strftime("%b %d, %H:%M"), risk, status, fraud_type))
            flash(f"Transaction added and classified as {status}.", "success")
            return redirect(url_for("transactions"))
        except (ValueError, KeyError, sqlite3.IntegrityError):
            flash("Check your values. Transaction ID must be unique, amount non-negative, and risk score 0–100.", "error")
    return render_template("add_transaction.html", active="add")

@app.route("/api/health")
def health():
    return {"status": "ok", "application": "FraudGuard AI demo"}

init_db()

if __name__ == "__main__":
    app.run(debug=True)
